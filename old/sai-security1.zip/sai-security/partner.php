<section  class="partner-section">
			<div class="container">
			<div class="sec-title">
					<span>Partner</span>
					<h2>Authorized Business Partner</h2>
				</div><!--sec-title end-->
				
				<ul class="pt-carousel">
					<li><img src="assets/images/partner/b1.png" alt=""></li>
					<li><img src="assets/images/partner/b2.png" alt=""></li>
					<li><img src="assets/images/partner/b3.png" alt=""></li>
					<li><img src="assets/images/partner/b4.png" alt=""></li>
					<li><img src="assets/images/partner/b5.png" alt=""></li>
					<li><img src="assets/images/partner/b6.png" alt=""></li>
					<li><img src="assets/images/partner/b7.png" alt=""></li>
					<li><img src="assets/images/partner/b8.png" alt=""></li>
					<li><img src="assets/images/partner/b9.png" alt=""></li>
					<li><img src="assets/images/partner/b10.png" alt=""></li>
					
				</ul><!--pt-carousel end-->
			</div>
		</section><!--partner-section end-->