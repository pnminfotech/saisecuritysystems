<footer>
			<div class="main-footer">
				<div class="container">
					<div class="row">
						<div class="col-lg-3 col-md-6 col-sm-6">
							<div class="widget widget-about">
								<img src="assets/images/logo.png" alt="">
								<p>Sai security systems is an independent and neutral company of professionals offering all typesof CCTV Surveillance System, Time-Attendance System, P&A System, Entrance Automation System and Government work related tenders in all offering services respectively.</p>

							</div><!--widget-about end-->
						</div>
						<div class="col-lg-6 col-md-6 col-sm-6">
							<div class="widget widget-services">
								<h3 class="widget-title">Services</h3>
                                <div class="row">
								<ul class="col-md-6">
									<li><i class="fa fa-check"></i> <span>IP CCTV Surveillance System</span></li>
									<li><i class="fa fa-check"></i> <span>Time & Attendance System</span></li>
									<li><i class="fa fa-check"></i> <span>Access Control System</span></li>
                                    <li><i class="fa fa-check"></i> <span>Video Door Phone</span></li>
                                    <li><i class="fa fa-check"></i> <span>Intercom System</span></li>
                                    <li><i class="fa fa-check"></i> <span>IP Public Address System</span></li>
                                   
                                    
                                   
								</ul>
                                <ul class="col-md-6">
									
                                  
                                    <li><i class="fa fa-check"></i> <span>Entrance Automation System</span></li>
                                    <li><i class="fa fa-check"></i> <span>Guard Patrolling System</span></li>
                                    <li><i class="fa fa-check"></i> <span>Automatic Boom Barrier</span></li>
                                    <li><i class="fa fa-check"></i> <span>Cloud Based Attendance</span></li>
                                    <li><i class="fa fa-check"></i> <span>Parking Management Solutions</span></li>
                                    <li><i class="fa fa-check"></i> <span>Fire Alarm System</span></li>
                                    <li><i class="fa fa-check"></i> <span>Fire Hydrant System</span></li>
								</ul>
</div>
							</div><!--widget-services end-->
						</div>
						<div class="col-lg-3">
							<div class="widget widget-services">
								<h3 class="widget-title">Reach Us</h3>
                                <ul>
									<li><i class="fa fa-map-marker-alt"></i> <span>Sai security systems, Prathamesh Apt. F2, PL RM-73 MIDC G BL Chinchwad, Pune</span></li>
									<li><i class="fa fa-envelope"></i> <span>sales@saisecuritysystems.com</span></li>
									<li><i class="fa fa-phone-volume"></i> <span>8208492120</span></li>
								</ul>
                                    </div>
                                <div class="widget widget-social">
								<ul class="socio-links">
									<li><a href="#" title=""><i class="fab fa-facebook-f"></i></a></li>
									<li><a href="#" title=""><i class="fab fa-linkedin-in"></i></a></li>
									<li><a href="#" title=""><i class="fab fa-twitter"></i></a></li>
									<li><a href="#" title=""><i class="fab fa-instagram"></i></a></li>
								</ul>
							</div><!--widget-social end-->
						</div>
					</div>
				</div>
			</div>
			<div class="bottom-strip">
				<div class="container">
					<div class="copyright-text">
						<p>Copyright © 2023, Sai Security System. All Right Reserved</p>
						<a href="#" title="" class="scrollUp"><i class="fa fa-level-up-alt"></i></a>
					</div>
				</div>
			</div>
		</footer><!--footer end-->