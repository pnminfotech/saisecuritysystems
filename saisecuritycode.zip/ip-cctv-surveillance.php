<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Sai Security System</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="" />
	<meta name="keywords" content="" />
	<link rel="icon" href="https://ik.imagekit.io/bbbb375wr/favicon.png">
	<link rel="stylesheet" type="text/css" href="assets/css/animate.css">
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="assets/css/all.min.css">
	<link rel="stylesheet" type="text/css" href="assets/js/plugin/slick.css">
	<link rel="stylesheet" type="text/css" href="assets/js/plugin/slick-theme.css">
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">
	<link rel="stylesheet" type="text/css" href="assets/css/responsive.css">
	<link rel="stylesheet" type="text/css" href="assets/css/color.css">
</head>


<body>

	
	<div class="wrapper">
		
	<?php include 'header.php' ?>

		<section class="pager-sec overlay-dark">
			<div class="container">
				<div class="pager-sec-details">
					<h2>IP CCTV Surveillance System</h2>
					<ul class="breadcrumb">
						<li><a href="index.php" title="">Home</a></li>
						<li><span>Services</span></li>
					</ul>
				</div><!--pager-sec-details end-->
			</div>
		</section><!--pager-sec end-->

		<section class="page-content">
			<div class="container">
				<div class="services-page">
					<div class="row">
						<div class="col-lg-4">
							<div class="sidebar">
								<div class="widget widget-recent-services">
									<ul>
										<li><a href="ip-cctv-surveillance.php" title="" class="active">IP CCTV Surveillance System</a></li>
										<li><a href="time-attendance-system.php" title="">Time & Attendance System</a></li>
										<li><a href="access-control-system.php" title="">Access Control System</a></li>
										<li><a href="video-door-phone.php" title="">Video Door Phone System</a> </li>
										<li><a href="intercom-system.php" title="">Intercom System</a> </li>
										<li><a href="ip-public-address.php" title="">IP Public Address System</a> </li>
										<li><a href="entrance-automation-system.php" title="">Entrance Automation System</a> </li>
										<li><a href="guard-patrolling-system.php" title="">Guard Patrolling System</a> </li>
										<li><a href="automatic-boom-barrier-system.php" title="">Automatic Boom Barrier System</a> </li>
										<li><a href="cloud-based-attendance-system.php" title="">Cloud Based Attendance System</a> </li>
										<li><a href="parking-management-solutions.php" title="">Parking Management Solutions </a> </li>
										<li><a href="fire-alarm-system.php" title="">Fire Alarm System</a> </li>
										<li><a href="fire-hydrant-system.php" title="">Fire Hydrant System</a> </li>
									
									</ul>
								</div><!--widget-recent-services end-->
							</div><!--sidebar end-->
						</div>


						<div class="col-lg-8">
							<div class="content-details">
								
								<h2>IP CCTV Surveillance System</h2>
								<h4>IP cameras from CCTV Camera World are the best security cameras.</h4>
								<img src="https://ik.imagekit.io/bbbb375wr/service/ip-cctv.jpg" alt="">
								<p>Our IP CCTV surveillance system offers the most optimum solution for indoor as well as outdoor surveillance.
<br>Our range of surveillance systems caterto a wide range of applications like homes, malls,offices, shops, schools and lots more. We provides wide range of Analog and IP Cameras</p>
							<p> There are several types of IP cameras such as dome and bullet IP cameras, variable-lens cameras, PTZ cameras, indoor and outdoor, wireless, those designed for night applications, and others that can be used for long-range surveillance applications. IP camera systems are used to enhance the safety and security in schools, business, healthcare, industrial, military, and government organizations.</p>
						
								
							</div><!--content-details end-->
						</div>
					</div>
				</div><!--services-page end-->
			</div>
		</section><!--page-content end-->

	<section class="partner-background" >
		<?php include 'partner.php'?>
		<!--partner-section end-->
</section>
		<?php include 'footer.php' ?>
	</div><!--wrapper end-->



<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/popper.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/jquery.validate.min.js"></script>
<script src="assets/js/validator.js"></script>
<script src="assets/js/plugin/slick.min.js"></script>
<script src="assets/js/script.js"></script>


</body>

</html>